<!DOCTYPE html>
<?php
    // DB接続設定
    $dsn = 'データベース名';
    $user = 'ユーザー名';
    $password = 'パスワード';
    $pdo = new PDO($dsn, $user, $password, array(PDO::ATTR_ERRMODE => PDO::ERRMODE_WARNING));
    
    //テーブル作成 
    $sql = "CREATE TABLE IF NOT EXISTS tbtom"
     ." ("
    . "id INT AUTO_INCREMENT PRIMARY KEY,"
    . "name char(32),"
    . "str TEXT,"
    . "date TEXT,"
    . "password TEXT"
    .");";
    $stmt = $pdo->query($sql);
    
    if(!empty($_POST["submit2"])){//編集送信を受け取ったとき
        if(!empty($_POST["edit"]) && !empty($_POST["pass3"])){
            $edit = $_POST["edit"];
            $pass3 = $_POST["pass3"];
          
            $sql = 'SELECT * FROM tbtom';
            $stmt = $pdo->query($sql);
            $results = $stmt->fetchAll();//複数行のデータをリスト形式に
            foreach ($results as $row){
                if($edit == $row['id']){
                    if($pass3 == $row['password']){
                        $name2 = $row['name'];
                        $str2 = $row['str'];
                    }
                }
            }
        }
    }
?>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <title>mission_5-1</title>
</head>
<body>
    <form action="" method="post">
        [　投稿フォーム　]
        <br>
        名前：　　　　<input type="txt" name="name"  value="<?php if(isset($name2)){echo $name2;} ?>">
        <br>
        コメント：　　<input type="txt" name="str" value="<?php if(isset($str2)){echo $str2;} ?>">
        <br>
        パスワード：　<input type="txt" name="pass1" >
        <br>
        <input type="submit" name="submit">
        <br>
        <br>
        [　消去フォーム　]
        <br>
        投稿番号：　　<input type="txt" name="number" >
        <br>
        パスワード：　<input type="txt" name="pass2" >
        <br>
        <input type="submit" name="submit1">
        <br>
        <br>
        [　編集フォーム　]
        <br>
        投稿番号：　　<input type="txt" name="edit" >
        <br>
        パスワード：　<input type="txt" name="pass3" >
        <br>
        <input type="submit" name="submit2">
        <br>
        <input type="hidden" size="5" name="editnum" value = "<?php if(!empty($_POST["edit"])){
                                                            echo $_POST["edit"];
                                                            }?>" >
                                                   
        <br>
        <br>
        [　投稿一覧　]
    </form>
    
</body>
</html>
<?php
    
    // DB接続設定
    $dsn = 'データベース名';
    $user = 'ユーザー名';
    $password = 'パスワード';
    $pdo = new PDO($dsn, $user, $password, array(PDO::ATTR_ERRMODE => PDO::ERRMODE_WARNING));
    
    //テーブル作成 
    $sql = "CREATE TABLE IF NOT EXISTS tbtom"
     ." ("
    . "id INT AUTO_INCREMENT PRIMARY KEY,"
    . "name char(32),"
    . "str TEXT,"
    . "date TEXT,"
    . "password TEXT"
    .");";
    $stmt = $pdo->query($sql);
    
    //投稿
    if(!empty($_POST["submit"]) && empty($_POST["editnum"])){ 
        if(!empty($_POST["pass1"])){
            $sql = $pdo -> prepare("INSERT INTO tbtom (name, str, date, password) VALUES (:name, :str, :date, :password)");
            $sql -> bindParam(':name', $name, PDO::PARAM_STR);
            $sql -> bindParam(':str', $str, PDO::PARAM_STR);
            $sql -> bindParam(':date', $date, PDO::PARAM_STR);
            $sql -> bindParam(':password', $pass1, PDO::PARAM_STR);
               
            $name = $_POST["name"];
            $str = $_POST["str"];
            $date = date("Y/m/d H:i:s");
            $pass1 = $_POST["pass1"];
                
            $sql -> execute();
                
            $sql = 'SELECT * FROM tbtom';
            $stmt = $pdo->query($sql);//$splに保存されているデータを取り出す
            $results = $stmt->fetchAll();//複数行のデータをリスト形式に
            foreach ($results as $row){
                echo $row['id'].',';
                echo $row['name'].',';
                echo $row['str'].',';
                echo $row['date'].'<br>';
                echo "<hr>";
            }
        }elseif(empty($_POST["name"]) || empty($_POST["str"]) || empty($_POST["pass1"]) ){//全ての項目が入力されていない場合
            echo "すべて入力してください","<br>";
            $sql = 'SELECT * FROM tbtom';
            $stmt = $pdo->query($sql);
            $results = $stmt->fetchAll();
            foreach ($results as $row){
                echo $row['id'].',';
                echo $row['name'].',';
                echo $row['str'].',';
                echo $row['date'].'<br>';
                echo "<hr>";
            }
        
        }
    }elseif(!empty($_POST["submit"]) && !empty($_POST["editnum"])){//編集投稿
        if(!empty($_POST["pass1"])){
            $editnum = $_POST["editnum"];
            $name = $_POST["name"];
            $str = $_POST["str"];
            $date = date("Y/m/d H:i:s");
            $pass1 = $_POST["pass1"];
        
            $sql = 'SELECT * FROM tbtom';
            $stmt = $pdo->query($sql);
            $results = $stmt->fetchAll();
            foreach ($results as $row){
                if($editnum == $row['id']){
                    $sql = 'UPDATE tbtom SET name=:name,str=:str,date=:date,password=:password WHERE id=:id';
                    $stmt = $pdo->prepare($sql);
                    $stmt->bindParam(':name', $name, PDO::PARAM_STR);
                    $stmt->bindParam(':str', $str, PDO::PARAM_STR);
                    $stmt->bindParam(':date', $date, PDO::PARAM_STR);
                    $stmt->bindParam(':password', $pass1, PDO::PARAM_STR);
                    $stmt->bindParam(':id', $editnum, PDO::PARAM_INT);
                    $stmt->execute();
                }
            }
            $sql = 'SELECT * FROM tbtom';
            $stmt = $pdo->query($sql);
            $results = $stmt->fetchAll();
            foreach ($results as $row){
                echo $row['id'].',';
                echo $row['name'].',';
                echo $row['str'].',';
                echo $row['date'].'<br>';
                echo "<hr>";
            }
        }elseif(empty($_POST["name"]) || empty($_POST["str"]) || empty($_POST["pass1"]) ){
            echo "すべて入力してください","<br>";
            $sql = 'SELECT * FROM tbtom';
            $stmt = $pdo->query($sql);
            $results = $stmt->fetchAll();
            foreach ($results as $row){
                echo $row['id'].',';
                echo $row['name'].',';
                echo $row['str'].',';
                echo $row['date'].'<br>';
                echo "<hr>";
            }
        
        }
    }elseif(!empty($_POST["submit1"])){//消去送信を受け取ったとき
        if(!empty($_POST["number"]) && !empty($_POST["pass2"])){
            $num = $_POST["number"];
            $pass2 = $_POST["pass2"];
          
            $sql = 'SELECT * FROM tbtom';
            $stmt = $pdo->query($sql);
            $results = $stmt->fetchAll();
            foreach ($results as $row){
                if($num == $row['id']){
                    if($pass2 == $row['password']){
                        $sql = 'delete from tbtom where id=:id';
                        $stmt = $pdo->prepare($sql);
                        $stmt->bindParam(':id', $num, PDO::PARAM_INT);
                        $stmt->execute();
                    }elseif($pass2 != $row['password']){
                        echo "パスワードが間違っています","<br>";
                    }
                }
            }
            $sql = 'SELECT * FROM tbtom';
            $stmt = $pdo->query($sql);
            $results = $stmt->fetchAll();
            foreach ($results as $row){
                echo $row['id'].',';
                echo $row['name'].',';
                echo $row['str'].',';
                echo $row['date'].'<br>';
                echo "<hr>";
            }
        }elseif(empty($_POST["number"]) || empty($_POST["pass2"]) ){
            echo "すべて入力してください","<br>";
            $sql = 'SELECT * FROM tbtom';
            $stmt = $pdo->query($sql);
            $results = $stmt->fetchAll();
            foreach ($results as $row){
                echo $row['id'].',';
                echo $row['name'].',';
                echo $row['str'].',';
                echo $row['date'].'<br>';
                echo "<hr>";
            }
        
        }
            
    }elseif(!empty($_POST["submit2"])){//編集送信を受け取ったとき
        if(!empty($_POST["edit"]) && !empty($_POST["pass3"])){
            $edit = $_POST["edit"];
            $pass3 = $_POST["pass3"];
          
            $sql = 'SELECT * FROM tbtom';
            $stmt = $pdo->query($sql);
            $results = $stmt->fetchAll();
            foreach ($results as $row){
                if($edit == $row['id']){
                    if($pass3 == $row['password']){
                        $name2 = $row['name'];
                        $str2 = $row['str'];
                    }elseif($pass3 != $row['password']){
                        echo "パスワードが間違っています","<br>";
                    }
                }
            }
            foreach ($results as $row){
                echo $row['id'].',';
                echo $row['name'].',';
                echo $row['str'].',';
                echo $row['date'].'<br>';
                echo "<hr>";
            }
        }elseif(empty($_POST["edit"]) || empty($_POST["pass3"]) ){
            echo "すべて入力してください","<br>";
            $sql = 'SELECT * FROM tbtom';
            $stmt = $pdo->query($sql);
            $results = $stmt->fetchAll();
            foreach ($results as $row){
                echo $row['id'].',';
                echo $row['name'].',';
                echo $row['str'].',';
                echo $row['date'].'<br>';
                echo "<hr>";
            }
        
        }
    }elseif(!empty($_POST["submit"]) || !empty($_POST["submit1"]) || !empty($_POST["submit2"])){
        if(empty($_POST["name"]) || empty($_POST["str"]) || empty($_POST["edit"])  ){
            echo "すべて入力してください","<br>";
            $sql = 'SELECT * FROM tbtom';
            $stmt = $pdo->query($sql);
            $results = $stmt->fetchAll();
            foreach ($results as $row){
                echo $row['id'].',';
                echo $row['name'].',';
                echo $row['str'].',';
                echo $row['date'].'<br>';
                echo "<hr>";
            }
        }
    }else{//掲示板の内容を常時表示させる
        $sql = 'SELECT * FROM tbtom';
        $stmt = $pdo->query($sql);
        $results = $stmt->fetchAll();
        foreach ($results as $row){
            echo $row['id'].',';
            echo $row['name'].',';
            echo $row['str'].',';
            echo $row['date'].'<br>';
            echo "<hr>";
        }     
    }
?>
    
    
 